<?php require "resources/conn.php"?>
<?php require "resources/seller_utility.php"?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Header/footer usage</title>

    
    <?php require "import_headInfo.php"?>
    <?php require "resources/import_sellerHeadInfo.php"?>
</head>
<body>
    <?php require "header.php"; ?>
    <br><br><br>

    Hello some sample content
    <br>
    <br>
    <br>
    Yes. Some content btw.
    <br><br><br><br><br><br>

    <p class="okayy" style="width: 500px; height:500px;">hello its red</p>

    <?php require "footer.php";?>
</body>
</html>