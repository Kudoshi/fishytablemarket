<!DOCTYPE html>
<html lang="en">
<head>
    <title>Header/footer usage</title>

    <?php require "import_headInfo.php"; ?>
    <?php require "resources/import_sellerHeadInfo.php"?>
</head>
<body>
    <?php require "header.php"; ?>

    <div class="container-fluid">
        <div class="row">
            <!-- Left Side -->
            <div class="d-sm-flex flex-sm-column align-items-center w-30 col-sm-4 bg-primary">
                sdf
            </div>
            <!-- Right Side -->
            <div class="col-sm-8 bg-warning">

            </div>
       


        </div>
    </div>


    <?php require "footer.php";?>
</body>
</html>