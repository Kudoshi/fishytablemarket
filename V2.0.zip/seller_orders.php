<?php require "resources/conn.php"?>
<?php require "resources/seller_utility.php"?>
<?php
   if (!isset($_SESSION["SellerID"]))
   {
       header("Location: seller_login.php");
       return;
   }
   $data = sql_retrieveRecord($con, "seller", "SellerID", $_SESSION["SellerID"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Fishytable Market</title>
    
    <?php require "import_headInfo.php"?>
    <?php require "resources/import_sellerHeadInfo.php"?>
</head>
<body>
    <?php require "header_seller.php"; ?>
   
    <div class="container-fluid">
        <div class="text-end display-6 bg-color-black-2 text-white row py-4">
            <div class="me-4 pe-4 col-md-11">
                <span class="fs-4 ">View All Orders</span>
                <span class="text-primary px-2">|</span>
                <span class="text-gray-2 display-6">Orders</span>
            </div>
            <div class="col-md-1"></div>
        </div>

        <!-- Container -->
        <div class="p-4 mx-4 mb-4 mt-4">
            <div class="bg-color-white-3 border rounded-3 p-4" style="min-height: 600px;" id="id_orderContainer">
                <div class="d-flex bg-color-white-1" style="max-height: 400px;">
                    <br><br><br><br>sdf
                </div>
            </div>
        </div>


        

    </div>
    <?php require "footer_seller.php";?>
</body>
</html>