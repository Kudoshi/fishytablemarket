<?php require "resources/conn.php"?>
<?php require "resources/seller_utility.php"?>
<!DOCTYPE HTML>
<html>
<head>
    <?php require "import_headInfo.php"; ?>
    <?php require "resources/import_sellerHeadInfo.php"?>
</head>
<body>
    <?php 
        $number = "123";

        if(!is_numeric($number) || !is_float($number + 0))
        {
            
            echo "XXXXX NOT FLOAT";
        }
        else{
            echo "Is Float";
        }
    ?>
</body>
</html>