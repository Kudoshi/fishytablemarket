<?php require "resources/conn.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Header/footer usage</title>

    
    <?php require "import_headInfo.php"; ?>
    <!-- More stuff can be put below here -->
</head>
<body>
    <?php require "header.php"; ?>
    <br><br><br>

    Hello some sample content
    <br>
    <br>
    <br>
    Yes. Some content btw.
    <br><br><br><br><br><br>


    <?php require "footer.php";?>
</body>
</html>