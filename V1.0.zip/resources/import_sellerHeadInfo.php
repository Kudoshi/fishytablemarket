
    <link rel="stylesheet" href="css/seller_page.css">
    <script src="js/seller_jsEffects.js"></script>
    
    